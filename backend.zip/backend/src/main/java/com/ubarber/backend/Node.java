package com.ubarber.backend;

public class Node {

}

package com.ubarber.backend;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pojos.*;
import services.*;

import java.net.http.HttpResponse;

@RestController
public class NodeController {

	@Value("${database.uri}")
	private String database;

	@PostMapping("/registerBarber")
	public ResponseEntity<EntityModel<Barber>> registerBarber(@RequestBody Barber barber) throws JsonProcessingException {
		ResponseEntity<EntityModel<Barber>> response = ProfileService.registerBarberProfile("http://localhost:8080", barber);
		return response;
	}
	@PostMapping("/registerClient")
	public ResponseEntity<EntityModel<Client>> registerClient(@RequestBody Client client) {
		ResponseEntity<EntityModel<Client>> response = ProfileService.registerClientProfile("http://localhost:8080", client);
		return response;
	}
	@GetMapping("/getBarber/{id}")
	public ResponseEntity<EntityModel<Barber>> getBarber(@PathVariable long id) throws JsonProcessingException {
		return BrowseBarberService.getBarberProfile("http://localhost:8080" , id);
	}

	@GetMapping("/getBarbersNearMe")
	public ResponseEntity<CollectionModel<Barber>> getBarbersNearMe(@RequestBody Client client) throws JsonProcessingException {
		//todo Hash client location to get the right DB
		String clientDbUri = "http://localhost:8080";
		ResponseEntity<CollectionModel<Barber>> response = BrowseBarberService.getBarbersNearMe(clientDbUri , client);
		return response;
	}

	@GetMapping("/updateSchedule/{id}")
	public HttpResponse<String> updateSchedule(@RequestBody String appointmentSlotJson, @PathVariable long id) {
		return BarberSideServices.updateSchedule("http://localhost:8080", id, appointmentSlotJson);
	}

	@GetMapping("/cancelAppointment/{id}")
	public HttpResponse<String> cancelAppointment(@PathVariable long id) {
		return BarberSideServices.cancelAppointment("http://localhost:8080", id);
	}

	@GetMapping("/updateProfile/{id}")
	public HttpResponse<String> updateProfile(@RequestBody String barberJson, @PathVariable long id) {
		return BarberSideServices.updateProfile("http://localhost:8080", id, barberJson);
	}

	@GetMapping("/barberSchedule/{id}")
	public ResponseEntity<CollectionModel<AppointmentSlot>> getBarberSchedule(@RequestBody String barberJson, @PathVariable long id){
		return BookingService.getBarberSchedule(database, id);
	}

	@PostMapping("/appointments/{id}")
	public ResponseEntity<EntityModel<Appointment>> bookBarber(@RequestBody String appointmentJson, @PathVariable long id){
		Gson gson = new Gson();
		int clientId = gson.fromJson("clientID", Integer.TYPE);
		int slotId = gson.fromJson("slotID", Integer.TYPE);
		return BookingService.bookBarber(database, id, clientId, slotId);
	}

	@DeleteMapping("/appointments/{id}")
	public ResponseEntity<EntityModel<Appointment>> cancelAppointmentClientSide(@PathVariable long id){
		return BookingService.cancelAppointment(database, id);
	}

}

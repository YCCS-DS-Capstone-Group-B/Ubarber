package services;

import org.json.JSONObject;
import pojos.*;
import utils.Http;

import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class BarberSideServices {

    /**
     * @param uri the uri of the database
     * @param id
     * @return
     */
    public static HttpResponse<String> cancelAppointment(String uri, long id) {
        return Http.delete(uri + "/appointments/" + id);
    }

    public static HttpResponse<String> updateSchedule(String uri, long id, String appointmentSlotJson) {
        return Http.put(uri + "/appointmentSlots/" + id, appointmentSlotJson);
    }

    public static HttpResponse<String> updateProfile(String uri, long id, String barberJson) {
        return Http.put(uri + "/barbers/" + id, barberJson);
    }
}
package services;

public class RatingService {

    public int postComment() {
        return 0;
    }

    public int postRating() {
        return 0;
    }
}